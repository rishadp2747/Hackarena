<nav class="navbar navbar-expand-lg ">
    <a class="navbar-brand" href="#">
        <img src="{{asset('img/logo/logo.png')}}" width="50" height="50" class="d-inline-block align-middle mr-3" alt="">
        Hackarena 2.0
    </a>

    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
            <a class="nav-link" href="#">Login</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Register</a>
            </li>
        </ul>
        
    </div>
</nav>