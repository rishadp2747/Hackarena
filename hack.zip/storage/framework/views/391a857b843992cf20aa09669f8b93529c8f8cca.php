<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-flex justify-content-center align-content-center h-50 slide" >
        <img src="<?php echo e(asset('img/slide.png')); ?>"  class="w-100" height="650">
    </div>

    <div class="container">

        <div class="d-flex  flex-row justify-content-center align-content-center  ">
            <div class=" text-center register-content w-100 mb-5" > 
                <h3>LOGIN</h3>
                <form method="POST" action="<?php echo e(route('login')); ?>>
                        <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" aria-describedby="usernameHelp" placeholder="Enter Userame">
                        
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
                    </div>
                    
                    <div class="d-flex justify-content-end w-100 flex-row py-4 pl-4 ">
                        
                        <button type="submit" class="btn btn-outline-primary  ml-2 ">Cancel</button>
                        <button type="submit" class="btn btn-outline-primary ml-2 ">Login</button>

                    </div>
                    

                    <div class="d-flex justify-content-center w-100 mt-4  p-2 reg-footer">
                            <a href="#" >I Don't have an account. Register ..</a><br>
                    </div>
                </form>
            </div>
        
        </div>

    </div>

    <div class="footer d-flex  justify-content-center">
        
         <div class="pt-4 text-center">
            <p class="design">Developed & Designed by <a href="#">FCS</a></p>
            <p class="copy">All right &copy; 2019-20 reserved </p>
        </div>
      
    </div>
    



<?php $__env->stopSection(); ?>
    




 
<?php echo $__env->make('layout.outline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rishad/Documents/FCS/Hackarena/15 march 2020/dev/hackarena/resources/views/auth/login.blade.php ENDPATH**/ ?>