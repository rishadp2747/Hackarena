<?php echo e($slot); ?>

<?php /**PATH /media/rishad/Documents/FCS/Hackarena/15 march 2020/dev/hackarena/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>