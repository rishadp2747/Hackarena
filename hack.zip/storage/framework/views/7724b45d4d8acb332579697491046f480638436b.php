<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /media/rishad/Documents/FCS/Hackarena/15 march 2020/dev/hackarena/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>