<!DOCTYPE html>
<html>
    <head>
        <title>HackArena | </title>
        <!--meta tags -->
        <link rel="icon" href="<?php echo e(asset('img/logo/icon.png')); ?>" type="image/x-icon"/>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">


    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
       
    </body>
   
   
</html><?php /**PATH /media/rishad/Documents/FCS/Hackarena/15 march 2020/dev/hackarena/resources/views/layout/outline.blade.php ENDPATH**/ ?>