Thanks for downloading and don't forget to donate is you liked this font ! -> https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JF3NNU43JJ7E6

By downloading and using the font called HACKED, you agreed this condition :
Like the licence CC-BY (https://creativecommons.org/licenses/by/4.0/) saying, if you use this font into a published creation, YOU MUST indicate your source by credit the author "David Libeau" and the font's name "Hacked". You can also link the page http://bit.ly/WatchDogsFont.

Discover my other works at http://DavidLibeau.fr